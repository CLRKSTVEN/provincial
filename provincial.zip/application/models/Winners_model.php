<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Winners_model extends CI_Model
{
    public function insert_winner($data)
    {
        return $this->db->insert('winners', $data);
    }

    // Medal tally by municipality (all groups)
    public function get_medal_tally()
    {
        $this->db->select("
            municipality,
            SUM(medal = 'Gold')   AS gold,
            SUM(medal = 'Silver') AS silver,
            SUM(medal = 'Bronze') AS bronze,
            COUNT(*)              AS total_medals
        ", FALSE);
        $this->db->from('winners');
        $this->db->group_by('municipality');
        $this->db->order_by('gold', 'DESC');
        $this->db->order_by('silver', 'DESC');
        $this->db->order_by('bronze', 'DESC');
        $this->db->order_by('municipality', 'ASC');

        return $this->db->get()->result();
    }

    // Medal tally by municipality + group (Elementary / Secondary)
    public function get_medal_tally_by_group($event_group)
    {
        $this->db->select("
            municipality,
            event_group,
            SUM(medal = 'Gold')   AS gold,
            SUM(medal = 'Silver') AS silver,
            SUM(medal = 'Bronze') AS bronze,
            COUNT(*)              AS total_medals
        ", FALSE);
        $this->db->from('winners');
        $this->db->where('event_group', $event_group);
        $this->db->group_by(array('municipality', 'event_group'));
        $this->db->order_by('gold', 'DESC');
        $this->db->order_by('silver', 'DESC');
        $this->db->order_by('bronze', 'DESC');
        $this->db->order_by('municipality', 'ASC');

        return $this->db->get()->result();
    }
}
