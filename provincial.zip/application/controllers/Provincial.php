<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Provincial extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Winners_model');
        $this->load->library(array('form_validation', 'session'));
        $this->load->helper(array('url', 'form'));
    }

    /**
     * PUBLIC LANDING PAGE
     * URL: http://localhost/provincial/
     */
    public function index()
    {
        $group = $this->input->get('group', TRUE);

        if ($group === 'Elementary' || $group === 'Secondary') {
            $data['active_group'] = $group;
            $data['tally']        = $this->Winners_model->get_medal_tally_by_group($group);
        } else {
            $data['active_group'] = 'ALL';
            $data['tally']        = $this->Winners_model->get_medal_tally();
        }

        // simple landing page (NO sidebar / top nav)
        $this->load->view('provincial_landing', $data);
    }

    /**
     * (Optional) if you still want the old internal standings page
     */
    public function standings()
    {
        // can just reuse index or load a different view
        $this->index();
    }

    /**
     * ADMIN PAGE – encode winners (with full admin template)
     * URL: http://localhost/provincial/index.php/provincial/admin
     */
    public function admin()
    {
        if ($this->input->post('submit')) {

            $this->form_validation->set_rules('first_name', 'First Name', 'required|trim');
            $this->form_validation->set_rules('last_name', 'Last Name', 'required|trim');
            $this->form_validation->set_rules('event_name', 'Event', 'required|trim');
            $this->form_validation->set_rules('event_group', 'Group', 'required|trim');
            $this->form_validation->set_rules('medal', 'Medal', 'required|trim');
            $this->form_validation->set_rules('municipality', 'Municipality', 'required|trim');

            if ($this->form_validation->run()) {
                $insert = array(
                    'first_name'   => $this->input->post('first_name', TRUE),
                    'middle_name'  => $this->input->post('middle_name', TRUE),
                    'last_name'    => $this->input->post('last_name', TRUE),
                    'event_name'   => $this->input->post('event_name', TRUE),
                    'event_group'  => $this->input->post('event_group', TRUE),
                    'category'     => $this->input->post('category', TRUE),
                    'medal'        => $this->input->post('medal', TRUE),
                    'municipality' => $this->input->post('municipality', TRUE),
                );

                $this->Winners_model->insert_winner($insert);
                $this->session->set_flashdata('success', 'Winner saved successfully.');
                redirect('provincial/admin');
                return;
            }
        }

        // this one can keep using your admin shell with sidebar/top-nav
        $this->load->view('provincial_admin_winner_form');
    }
}
