<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php'); ?>

<style>
    body {
        background-color: #f4f6fb;
    }

    .landing-page-wrapper {
        min-height: 100vh;
        display: flex;
        align-items: stretch;
    }

    .landing-left-img {
        min-height: 100vh;
        object-fit: cover;
    }

    .landing-card {
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 100vh;
        padding: 30px 15px;
    }

    .landing-card-inner {
        width: 100%;
        max-width: 900px;
        border-radius: 16px;
        border: 1px solid #e0e6f1;
        box-shadow: 0 10px 30px rgba(15, 23, 42, 0.12);
        background: #ffffff;
        padding: 24px 24px 20px;
    }

    .landing-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
    }

    .landing-title h4 {
        margin-bottom: 0;
        font-weight: 700;
    }

    .landing-title small {
        color: #6b7280;
    }

    .group-pills .btn {
        border-radius: 999px;
        padding: 4px 14px;
        font-size: 0.78rem;
    }

    .medal-table thead th {
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.06em;
        border-top: 0;
        background: linear-gradient(135deg, #2563eb, #1d4ed8);
        color: #fff;
    }

    .medal-table tbody tr:hover {
        background-color: #f3f4ff;
    }

    .rank-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 26px;
        height: 26px;
        border-radius: 50%;
        font-weight: 700;
        font-size: 0.78rem;
        color: #111827;
        background: #e5e7eb;
    }

    .rank-1 .rank-badge {
        background: linear-gradient(135deg, #facc15, #eab308);
    }

    .rank-2 .rank-badge {
        background: #e5e7eb;
    }

    .rank-3 .rank-badge {
        background: #fed7aa;
    }

    .medal-pill {
        display: inline-flex;
        align-items: center;
        padding: 2px 8px;
        border-radius: 999px;
        font-size: 0.75rem;
        font-weight: 600;
        background: #f9fafb;
    }

    .medal-gold {
        color: #b8860b;
    }

    .medal-silver {
        color: #6b7280;
    }

    .medal-bronze {
        color: #8b4513;
    }

    .small-muted {
        font-size: 0.8rem;
        color: #6b7280;
    }

    @media (max-width: 991.98px) {
        .landing-left-col {
            display: none;
        }

        .landing-card {
            min-height: 100vh;
        }
    }
</style>

<body>

    <!-- Loader (reuse from your template)-->
    <div class="loader-wrapper">
        <div class="loader">
            <div class="loader-bar"></div>
            <div class="loader-bar"></div>
            <div class="loader-bar"></div>
            <div class="loader-bar"></div>
            <div class="loader-bar"></div>
            <div class="loader-ball"></div>
        </div>
    </div>

    <section class="landing-page-wrapper">
        <div class="container-fluid">
            <div class="row no-gutters">

                <!-- Left image -->
                <div class="col-xl-5 col-lg-5 col-md-4 landing-left-col">
                    <img class="landing-left-img w-100"
                        src="<?= base_url(); ?>assets/images/login/2.jpg"
                        alt="Provincial Meet">
                </div>

                <!-- Right card -->
                <div class="col-xl-7 col-lg-7 col-md-8 d-flex justify-content-center p-0">
                    <div class="landing-card w-100">
                        <div class="landing-card-inner">

                            <!-- Header -->
                            <div class="landing-header">
                                <div class="landing-title">
                                    <h4>Provincial Meet Medal Standings</h4>
                                    <small>
                                        Live standings based on results encoded by the admin.
                                        This page refreshes automatically.
                                    </small>
                                </div>
                                <div class="group-pills">
                                    <?php $group = isset($active_group) ? $active_group : 'ALL'; ?>
                                    <a href="<?= site_url(); ?>"
                                        class="btn btn-sm <?= $group === 'ALL' ? 'btn-primary' : 'btn-outline-primary'; ?>">
                                        All
                                    </a>
                                    <a href="<?= site_url('?group=Elementary'); ?>"
                                        class="btn btn-sm <?= $group === 'Elementary' ? 'btn-primary' : 'btn-outline-primary'; ?>">
                                        Elementary
                                    </a>
                                    <a href="<?= site_url('?group=Secondary'); ?>"
                                        class="btn btn-sm <?= $group === 'Secondary' ? 'btn-primary' : 'btn-outline-primary'; ?>">
                                        Secondary
                                    </a>
                                </div>
                            </div>

                            <hr style="border:0;height:2px;background:linear-gradient(90deg,#2563eb 0%,#7c3aed 50%,#ec4899 100%);border-radius:999px;margin-top:4px;margin-bottom:8px;">

                            <!-- Medal table -->
                            <div class="table-responsive">
                                <table class="table table-sm table-hover medal-table mb-1">
                                    <thead>
                                        <tr>
                                            <th class="text-center" style="width:45px;">#</th>
                                            <th>Municipality</th>
                                            <th class="text-center" style="width:80px;">Gold</th>
                                            <th class="text-center" style="width:80px;">Silver</th>
                                            <th class="text-center" style="width:80px;">Bronze</th>
                                            <th class="text-center" style="width:80px;">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (!empty($tally)): ?>
                                            <?php $rank = 1; ?>
                                            <?php foreach ($tally as $row): ?>
                                                <tr class="rank-<?= $rank <= 3 ? $rank : ''; ?>">
                                                    <td class="text-center align-middle">
                                                        <span class="rank-badge"><?= $rank++; ?></span>
                                                    </td>
                                                    <td class="align-middle">
                                                        <?= htmlspecialchars($row->municipality, ENT_QUOTES, 'UTF-8'); ?>
                                                    </td>
                                                    <td class="text-center align-middle">
                                                        <span class="medal-pill medal-gold">
                                                            <?= (int)$row->gold; ?>
                                                        </span>
                                                    </td>
                                                    <td class="text-center align-middle">
                                                        <span class="medal-pill medal-silver">
                                                            <?= (int)$row->silver; ?>
                                                        </span>
                                                    </td>
                                                    <td class="text-center align-middle">
                                                        <span class="medal-pill medal-bronze">
                                                            <?= (int)$row->bronze; ?>
                                                        </span>
                                                    </td>
                                                    <td class="text-center align-middle font-weight-bold">
                                                        <?= (int)$row->total_medals; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="6" class="text-center py-4 text-muted">
                                                    No results yet. Please wait for the organizers to encode winners.
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Footer text -->
                            <p class="small-muted mt-2 mb-0 text-right">
                                For admin encoding, go to <code>/provincial/admin</code>.
                            </p>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- JS like in home_page.php -->
    <script src="<?= base_url(); ?>assets/js/jquery-3.5.1.min.js"></script>
    <script src="<?= base_url(); ?>assets/js/bootstrap/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url(); ?>assets/js/icons/feather-icon/feather.min.js"></script>
    <script src="<?= base_url(); ?>assets/js/icons/feather-icon/feather-icon.js"></script>
    <script src="<?= base_url(); ?>assets/js/config.js"></script>
    <script src="<?= base_url(); ?>assets/js/script.js"></script>

    <script>
        // Auto-refresh every 30s
        setTimeout(function() {
            window.location.reload();
        }, 30000);
    </script>

</body>

</html>