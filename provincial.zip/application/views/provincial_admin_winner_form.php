<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php'); ?>

<body>
    <div id="wrapper">

        <?php include('includes/top-nav-bar.php'); ?>
        <?php include('includes/sidebar.php'); ?>

        <div class="content-page">
            <div class="content">
                <div class="container-fluid">

                    <!-- Page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-flex align-items-center justify-content-between">
                                <div>
                                    <h4 class="page-title mb-0">Provincial Meet – Encode Winners</h4>
                                    <p class="text-muted mb-0" style="font-size: 0.85rem;">
                                        Entries saved here will automatically update the live medal standings.
                                    </p>
                                </div>
                                <div>
                                    <a href="<?= site_url('provincial/standings'); ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="mdi mdi-trophy"></i> View Standings
                                    </a>
                                </div>
                            </div>
                            <hr style="border:0;height:2px;background:linear-gradient(90deg,#10b981 0%,#3b82f6 50%,#6366f1 100%);border-radius:999px;margin-top:4px;">
                        </div>
                    </div>

                    <!-- Alerts -->
                    <div class="row">
                        <div class="col-md-8">
                            <?php if ($this->session->flashdata('success')): ?>
                                <div class="alert alert-success alert-dismissible fade show">
                                    <?= $this->session->flashdata('success'); ?>
                                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                                </div>
                            <?php endif; ?>

                            <?= validation_errors('<div class="alert alert-danger alert-dismissible fade show"><button type="button" class="close" data-dismiss="alert">&times;</button>', '</div>'); ?>
                        </div>
                    </div>

                    <!-- Form -->
                    <div class="row">
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-body">

                                    <?= form_open('provincial/admin'); ?>

                                    <div class="form-row">
                                        <div class="form-group col-md-4">
                                            <label>First Name <span class="text-danger">*</span></label>
                                            <input type="text" name="first_name" class="form-control"
                                                value="<?= set_value('first_name'); ?>" required>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label>Middle Name</label>
                                            <input type="text" name="middle_name" class="form-control"
                                                value="<?= set_value('middle_name'); ?>">
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label>Last Name <span class="text-danger">*</span></label>
                                            <input type="text" name="last_name" class="form-control"
                                                value="<?= set_value('last_name'); ?>" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label>Event <span class="text-danger">*</span></label>
                                        <input type="text" name="event_name" class="form-control"
                                            placeholder="e.g. 100m Dash (Boys) – Elementary"
                                            value="<?= set_value('event_name'); ?>" required>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-4">
                                            <label>Group <span class="text-danger">*</span></label>
                                            <select name="event_group" class="form-control" required>
                                                <option value="">-- Select Group --</option>
                                                <option value="Elementary" <?= set_select('event_group', 'Elementary'); ?>>Elementary</option>
                                                <option value="Secondary" <?= set_select('event_group', 'Secondary'); ?>>Secondary</option>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label>Category</label>
                                            <input type="text" name="category" class="form-control"
                                                placeholder="e.g. Boys, Girls, Team"
                                                value="<?= set_value('category'); ?>">
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label>Medal <span class="text-danger">*</span></label>
                                            <select name="medal" class="form-control" required>
                                                <option value="">-- Select Medal --</option>
                                                <option value="Gold" <?= set_select('medal', 'Gold');   ?>>Gold</option>
                                                <option value="Silver" <?= set_select('medal', 'Silver'); ?>>Silver</option>
                                                <option value="Bronze" <?= set_select('medal', 'Bronze'); ?>>Bronze</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label>Municipality <span class="text-danger">*</span></label>
                                        <input type="text" name="municipality" class="form-control"
                                            placeholder="e.g. Lupon, Mati City"
                                            value="<?= set_value('municipality'); ?>" required>
                                    </div>

                                    <button type="submit" name="submit" value="1" class="btn btn-success">
                                        <i class="mdi mdi-content-save-outline"></i> Save Winner
                                    </button>

                                    <?= form_close(); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Small note / instructions -->
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title mb-2">How this works</h5>
                                    <ol class="pl-3 mb-3" style="font-size: 0.9rem;">
                                        <li>Encode winners per event (Gold, Silver, Bronze).</li>
                                        <li>Each entry is tied to one municipality.</li>
                                        <li>The standings page automatically recalculates medal totals.</li>
                                    </ol>
                                    <p class="text-muted mb-0" style="font-size: 0.85rem;">
                                        You can later extend this page to support bulk upload from Excel / CSV
                                        based on your <code>Results.xlsx</code> layout.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <?php include('includes/footer.php'); ?>

        </div>

    </div>

    <?php include('includes/footer_plugins.php'); ?>

</body>

</html>